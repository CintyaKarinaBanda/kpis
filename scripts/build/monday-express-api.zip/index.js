const serverless = require('serverless-http');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mondayRoutes = require('./mondayRoutes');

// Create Express app
const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('/api/monday', mondayRoutes);

// Default route
app.get('/', (req, res) => {
  res.json({ message: 'Monday.com API is running' });
});

// Export serverless handler
module.exports.handler = serverless(app);
