const serverless = require('serverless-http');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

// Create Express app
const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Monday.com routes
app.get('/api/monday/boards', (req, res) => {
  res.json({ message: 'List of boards', boards: [] });
});

app.get('/api/monday/board/:boardId', (req, res) => {
  res.json({ message: `Board data for ${req.params.boardId}`, data: {} });
});

app.post('/api/monday/board/:boardId/import', (req, res) => {
  res.json({ message: `Importing board ${req.params.boardId} to KPI Dashboard`, success: true });
});

// Default route
app.get('/', (req, res) => {
  res.json({ message: 'Monday.com API is running' });
});

// Export serverless handler
module.exports.handler = serverless(app);
