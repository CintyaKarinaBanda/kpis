const express = require('express');
const mondayController = require('./mondayController');

const router = express.Router();

// Monday.com routes
router.get('/boards', mondayController.listConfiguredBoards);
router.get('/board/:boardId', mondayController.getMondayBoardData);
router.get('/board/:boardId/mapping', mondayController.getColumnMapping);
router.post('/board/:boardId/mapping', mondayController.configureColumnMapping);
router.get('/board/:boardId/data', mondayController.getTransformedData);
router.post('/board/:boardId/import', mondayController.importToKPIDashboard);
router.get('/files', mondayController.getFile);

module.exports = router;
